import { NextRequest, NextResponse } from "next/server";

const adminPaths = [""];
const userPaths = [""];




export async function middleware(req: NextRequest) {
  const res = NextResponse.next();
  res.headers.set("Access-Control-Allow-Origin", "*");
  res.headers.set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.headers.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
  
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: res.headers, status: 204 });
  }
  
  const pathname = req.nextUrl.pathname;

  const isAdminRoute = adminPaths.some((path) => pathname.startsWith(path));
  const isUserRoute = userPaths.some((path) => pathname.startsWith(path));

  if (isAdminRoute || isUserRoute) {
    const authHeader = req.headers.get("Authorization");
    const token = authHeader?.split("Bearer ")[1];

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const verifyRes = await fetch("https://www.srmedia.org.in/api/v1/auth", {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!verifyRes.ok) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { role } = await verifyRes.json();
    if (role === "user" && isAdminRoute) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
  }

  return res;
}


export const config = {
    matcher: [
        "/api/",  // This will match all paths
    ],
};
